# M03 v0.7 — Data Contract

Input: `AgentInput/rea_evidence.jsonl`, optionally `Outputs/build_assets.json` (read-only), and local model API at `http://127.0.0.1:11434`. Model must NOT receive `PrivateEvaluation/*`, source Unity Editor provenance or ground truth.

Output: `Outputs/ollama_probe.json` (`status:ok`, `kind:local_model_probe`, elapsed_seconds), `Outputs/qwen_agent_guided.json` (`completed` boolean; `trace` carries timeout and brief metadata). `Outputs/evaluation_private_guided.json` is generated ONLY if `completed:true` and evaluation explicitly invoked.

Transport: local-only Ollama POST `/api/chat` with `think:false`, `format:json`, `stream:false`, `num_ctx:4096`, `num_predict` configurable (64–4096), timeout configurable 20–1800 sec. No remote/cloud endpoint accepted.

Conservatism: diagnostic-looking IL literals remain `candidate_only`; unknown scene TMP text is not prefab-origin proof; no unproven observations added on timeout. T001 retains not_proven until independent build evidence exists.
