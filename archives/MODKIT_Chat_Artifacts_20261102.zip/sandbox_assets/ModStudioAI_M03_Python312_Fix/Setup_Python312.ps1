﻿param(
  [switch]$SkipPipUpgrade
)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$venv = Join-Path $root '.venv'
$exe = Join-Path $venv 'Scripts\python.exe'

if (-not (Get-Command py -ErrorAction SilentlyContinue)) {
  throw 'Python launcher `py` not found. Install Python 3.12.10 (64-bit) first: https://www.python.org/downloads/release/python-31210/'
}
& py -3.12 -c 'import sys,struct; assert sys.version_info[:2] == (3,12); assert struct.calcsize("P")*8 == 64'
if ($LASTEXITCODE -ne 0) {
  throw 'Python 3.12 64-bit not found. Install it, reopen PowerShell, then rerun.'
}
if (-not (Test-Path $exe)) {
  & py -3.12 -m venv $venv
  if ($LASTEXITCODE -ne 0) { throw 'Could not create local .venv' }
}
if (-not $SkipPipUpgrade) {
  & $exe -m pip install --upgrade pip
  if ($LASTEXITCODE -ne 0) { throw 'pip upgrade failed' }
}
# Insist on prebuilt Windows wheels: no local C++ compilation is necessary.
& $exe -m pip install --only-binary=:all: 'UnityPy==1.25.4'
if ($LASTEXITCODE -ne 0) { throw 'UnityPy install failed. Check Python architecture, internet and pip index.' }
& $exe -c 'import sys,UnityPy,lz4.frame; print("Python:",sys.version.split()[0]); print("Interpreter:",sys.executable); print("UnityPy import: OK"); print("lz4 import: OK")'
if ($LASTEXITCODE -ne 0) { throw 'UnityPy import verification failed' }
Write-Host 'Project Python environment is ready. Run .\Run_M03.ps1 -Mode scan-assets'
